public class variablesPractice {

    public static void main (String [] args){

        // Declaring each variable with the proper data type.

        String title = "Dracula";
        String author = "Bram Stoker";
        int pages = 223;
        double price = 19.99;

        // Print in the screen the value of each variable.

        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("Pages: " + pages);
        System.out.println("Price: " + price);
    }
}
