import java.util.Arrays;

public class javaArrays {
    public static void main (String [] args){

        // Create and declare the superheros names in a array
        String[] superheros = {"Batman", "Superman", "Wonder Woman", "Spider Man", "Iron Man"};
        // Create and declare the introduction years of the superheros in a array
        int [] introductionYears = {1939, 1938, 1941, 1962, 1963};
        //Print in the screen all the superheros names
        System.out.println("Superheros names " + (Arrays.toString(superheros)));
        //Print the introduction year
        System.out.println("Introduction years " + (Arrays.toString(introductionYears)));
        //Print the original name of the third superhero
        System.out.println("Third superhero name is " +superheros[2]);
        //Modify the third superhero name
        superheros[2] = "Ricardo";
        //Print the modified name
        System.out.println("The modified name is " + superheros[2]);
        //Print the original introduction year
        System.out.println("The original introduction years is " + introductionYears[2]);
        //Modify the introduction year
        introductionYears[2] = 2005;
        //Print the modified introduction year
        System.out.println("The modified introduction year is " + introductionYears[2]);
        //Length of the superheros string
        System.out.println("Superheros length is " + superheros.length);
        //Length of the introduction year
        System.out.println("Introduction years length is " + introductionYears.length);

    }
}
