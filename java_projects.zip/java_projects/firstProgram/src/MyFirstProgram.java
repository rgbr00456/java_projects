public class MyFirstProgram {

    public static void main(String [] args){

        System.out.println("I'm a programmer");
        System.out.println("Let's change the code now...");
        System.out.println("it's what I do!");
    }
}
