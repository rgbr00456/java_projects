public class movieTickets {

    public static void main (String[] args){

       //Declaring and initializing the varibles
        String firstName = "Sandy";
        String lastName = "Jones";
        String movieTitle = "The Source Code";
        int ticketNumber = 8;
        double ticketPrice = 10.57;

        //Calculating the total price
        double totalPrice =  ticketNumber * ticketPrice;

        //Concatenate the First and Last Name
        String fullName = firstName + "" + lastName;
        fullName = fullName.toLowerCase();

        //Converting the movie title
        movieTitle = movieTitle.toUpperCase();

        //Printing all the information in the screen
        System.out.println("Congratulations!! You have successfully booked the tickets\n");
        System.out.println("Username: " + fullName);
        System.out.println("Movie: " + movieTitle);
        System.out.println("Number of Tickets: " + ticketNumber);
        System.out.println("Price per ticket: " + ticketPrice);
        System.out.println("Total price of 8 tickets: " + totalPrice);
        System.out.println("\nThank you for choosing us for booking your movie tickets");
        System.out.println("Enjoy your movie!!");

    }
}
