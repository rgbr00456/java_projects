public class HandlingText {

    public static void main( String [] args){

        // Declaring the string.
        String fruit = "Banana";

        // Length of a string.
        int length = fruit.length();
        System.out.println("The length of the string " + fruit + " is " + length + " letters.");

        // charAt() of a string.
        char letter = fruit.charAt(2);
        System.out.println("The letter in the index 2 is " + letter);

        // susbstring
        String part1 =  fruit.substring(0, 3);
        String part2 = fruit.substring(3, 6);

        System.out.println("The part one of the string " + fruit + " is " + part1 + " and the second is " + part2);

        // equals (anotherString)
        String fruit1 = "Banana";
        String fruit2 = "apple";
        String fruit3 = "Apple";

        boolean result1 = fruit.equals(fruit1);
        boolean result2 = fruit.equals(fruit3);

        System.out.println("The result is " + result1 + " and the second result is " + result2);

        // toLowerCase() and toUpperCase()
        String fruitLowerCase =  fruit.toLowerCase();
        String fruitUpperCase = fruit.toUpperCase();

        System.out.println("The fruit name in lower case is " + fruitLowerCase);
        System.out.println("The fruit name in the upper case is " + fruitUpperCase);

        // contains(sequence)
        boolean hasAna  = fruit.contains("ana");
        boolean hasApple = fruit.contains("apple");

        System.out.println("The fruit " + fruit + " contains 'ana'? " + hasAna);
        System.out.println("The fruit " + fruit + " contains 'apple'? " + hasApple);

        // replace (oldChar, newChar)
        String fruitLetterReplaced = fruit.replace("a", "o");

        System.out.println("The fruit after the replacement is " + fruitLetterReplaced);



    }
}
