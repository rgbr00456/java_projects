public class CurrencyConversion {

    public static void main (String [] args){

        // Declaring the variables and the values for them.

        double amountInUSD = 100.00;
        double amountInEUR;
        double exchangeRateUSDtoEUR = 0.85;

        // Print in the screen the previous amount in USD.

        System.out.println ("USD amount is: " + amountInUSD);

        // Conversion to EUR.

        amountInEUR = amountInUSD * exchangeRateUSDtoEUR;

        // Print in the screen the value of EUR after the conversation.

        System.out.println("EUR amount is: " + amountInEUR);

        // Deduct 55 EUR from the value.

        amountInEUR -= 55;

        //Print the new EUR value.

        System.out.println ("New EUR value is: " + amountInEUR);

        //Convert the remaining EUR to USD.

        amountInUSD = amountInEUR / exchangeRateUSDtoEUR;

        // Print the new amount in USD.

        System.out.printf("Amount in USD after converting back: %.2f", amountInUSD);


    }
}
