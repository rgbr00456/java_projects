public class stringsLab {

    public static void main (String [] args){

        String bookTitle = "The adventures of Captain Fantastic and the Magical Unicorn";
        int titleLength = bookTitle.length();
        System.out.println("The length of the book title is " + titleLength);

        //Declare and initialize the length of the shortened book title
        int maxLength =  20;

        //Shortened the book title
        String shortenedTitle = bookTitle.substring(0, maxLength);
        System.out.println("Original title: " + bookTitle);
        System.out.println("Shortened title: " + shortenedTitle);

        //Declare and initialize the searchWord
        String searchWord = "Captain";

        //Check if the searchWord is present in the book title
        boolean containsWord =  bookTitle.contains(searchWord);
        System.out.println("Does the title contain the word \"" + searchWord + "\"? " + containsWord);

    }
}
